# Bald Eagle Lab · White Agate favicon sets

Four approved White Agate variants of the black monochrome eagle. **Version 1 (Pearl White) is the
published default** for browser tabs and mobile home-screen icons. The other three are complete,
swappable alternatives; nothing rotates automatically.

| # | Name | Folder | Status |
|---|------|--------|--------|
| 1 | Pearl White | `v1-pearl-white-DEFAULT/` | **Default** (published): Warm pearl-white agate with soft cream striations. DEFAULT. |
| 2 | Slate Vein | `v2-slate-vein/` | Alternative: Cool white agate with grey-black veining and dendritic fern marks. |
| 3 | Silver Vein | `v3-silver-vein/` | Alternative: Blue-white agate with metallic silver veins; the eagle shows faint black marbling. |
| 4 | Warm Sand | `v4-warm-sand/` | Alternative: Cream and sand-brown banded agate. |

## What is in each folder

| File | Size | Use |
|------|------|-----|
| `favicon.ico` | 16, 32, 48 px | Legacy browsers and `/favicon.ico` requests |
| `favicon-16x16.png` | 16x16 | Browser tab (standard density) |
| `favicon-32x32.png` | 32x32 | Browser tab (high density), bookmarks |
| `apple-touch-icon.png` | 180x180 | iOS/iPadOS home screen. Opaque, full-bleed; iOS applies its own rounded mask |
| `icon-192.png` | 192x192 | Web app manifest (Android home screen) |
| `icon-512.png` | 512x512 | Web app manifest (splash / install) |
| `icon-maskable-512.png` | 512x512 | Web app manifest, `purpose: maskable`. Eagle kept inside the 80% safe zone so circular and squircle crops do not clip it |

The 16/32 px, 192/512 px and `favicon.ico` files keep the rounded agate tile with transparent corners.

## Use a variant on a site

Copy a variant's files to the site root (or any folder), then in `<head>`:

```html
<link rel="icon" href="favicon.ico" sizes="48x48">
<link rel="icon" href="favicon-32x32.png" type="image/png" sizes="32x32">
<link rel="icon" href="favicon-16x16.png" type="image/png" sizes="16x16">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="manifest" href="site.webmanifest">
```

Keep paths relative. Bald Eagle Lab is served from `/baldeaglelab/`, so a leading `/` would break them.
`site.webmanifest` in this ZIP is ready to use as written.

To switch the live site to another variant, run `python3 scripts/build-favicons.py` after changing
`DEFAULT` in that script (or copy the chosen folder's files over the ones in `site/public/`).

## Source artwork

Approved originals (1254x1254, unmodified) live in the repository at
`site/public/brand/agate/source/baldeaglelab-whiteagate-v{1..4}.png`. Exports are raster derivatives; they are not
vector masters. At 16 px the eagle reads as a silhouette (head, folder and scaffold merge); the detail is
intended for 32 px and above.

Licensed with the rest of the repository (MPL-2.0).
